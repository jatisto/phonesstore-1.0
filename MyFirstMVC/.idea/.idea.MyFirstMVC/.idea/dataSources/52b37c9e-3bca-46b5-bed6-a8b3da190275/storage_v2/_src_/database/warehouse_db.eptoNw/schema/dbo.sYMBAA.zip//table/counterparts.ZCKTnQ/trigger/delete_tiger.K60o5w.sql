CREATE TRIGGER delete_tiger
ON WareHouse_DB.dbo.counterparts
AFTER DELETE  AS
BEGIN
  DECLARE
  @c_qty as INT,
  @c_warehouse_id as INT

  SELECT @c_qty = i.qty FROM deleted i;
  SELECT @c_warehouse_id = i.warehouse_id FROM deleted i;

  UPDATE warehouse
  SET warehouse.income_qty = warehouse.income_qty - @c_qty
  FROM Counterparts
  WHERE warehouse.id = @c_warehouse_id

  PRINT 'TRIGGER [delete_tiger] worked'

END
go

