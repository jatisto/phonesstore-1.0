CREATE TRIGGER insert_tiger
ON WareHouse_DB.dbo.counterparts
AFTER INSERT  AS
BEGIN
  DECLARE
  @c_qty as INT,
  @c_warehouse_id as INT

  SELECT @c_qty = i.qty FROM inserted i;
  SELECT @c_warehouse_id = i.warehouse_id FROM inserted i;

  UPDATE warehouse
  SET warehouse.income_qty = warehouse.income_qty + @c_qty
  FROM Counterparts
  WHERE warehouse.id = @c_warehouse_id

  PRINT 'TRIGGER [insert_tiger] worked'

END
go

